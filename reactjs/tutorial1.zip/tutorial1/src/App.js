import logo from "./logo.svg";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <div className="App ">
      <header className="App-header ">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>

        
        <div class="btn-group" role="group" aria-label="Basic example">
          <button type="button" class="btn btn-primary btn-lg">
            Left
          </button>
          <button type="button" class="btn btn-success btn-lg">
            Middle
          </button>
          <button type="button" class="btn btn-danger btn-lg">
            Right
          </button>
        </div>
      </header>
    </div>
  );
}

export default App;
